//
// Created by Fir on 2024/2/1.
//

#pragma once
#ifndef ASTRA_CORE_SRC_ASTRA_APP_H_
#define ASTRA_CORE_SRC_ASTRA_APP_H_


namespace astra {

}

#endif //ASTRA_CORE_SRC_ASTRA_APP_H_
